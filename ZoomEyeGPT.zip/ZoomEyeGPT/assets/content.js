function E(){if(document.getElementById("zoomeye-modal-container"))return;const t=document.createElement("div");t.className="zoomeye-modal-container",t.id="zoomeye-modal-container";const e=document.createElement("div");e.className="zoomeye-modal-header",e.innerHTML=`
    <div class="zoomeye-modal-title">
      <img src="${chrome.runtime.getURL("icons/48_48.png")}" alt="ZoomEye Logo">
      ZoomEye GPT
    </div>
    <button class="zoomeye-modal-close" id="zoomeye-modal-close">×</button>
  `;const o=document.createElement("div");o.className="zoomeye-modal-content";const n=document.createElement("iframe");n.src=chrome.runtime.getURL("index.html"),n.id="zoomeye-iframe",o.appendChild(n),t.appendChild(e),t.appendChild(o),document.body.appendChild(t),document.getElementById("zoomeye-modal-close").addEventListener("click",y),v()}async function M(){document.getElementById("zoomeye-modal-container").classList.add("open");try{chrome.runtime.sendMessage({type:"INFO"},e=>{try{const o=document.getElementById("zoomeye-iframe");o==null||o.contentWindow.postMessage({type:"FROM_BACKGROUND",data:e},"*")}catch{}})}catch{console.log("Extension context invalidated, reloading content script")}}function y(){document.getElementById("zoomeye-modal-container").classList.remove("open");try{chrome.runtime.sendMessage({type:"CLOSE_MODAL"})}catch{console.log("Extension context invalidated, reloading content script")}}function v(){window.addEventListener("message",t=>{try{const e=document.getElementById("zoomeye-iframe");if(t.source!==(e==null?void 0:e.contentWindow))return;const o=t.data;chrome.runtime.sendMessage({type:o.type,data:o},n=>{try{e==null||e.contentWindow.postMessage({type:"FROM_BACKGROUND",data:n},"*")}catch{}})}catch{}})}chrome.runtime.onMessage.addListener((t,e,o)=>(t.type==="OPEN_MODAL"?M():t.type==="CLOSE_MODAL"&&y(),!1));E();const d=document.createElement("div"),a=d.attachShadow({mode:"closed"});d.id="zoomeye-tools-root";d.style.setProperty("width","0");d.style.setProperty("height","0");const l=document.createElement("link");l.rel="stylesheet";l.href=chrome.runtime.getURL("assets/content-script.css");a.appendChild(l);document.body.appendChild(d);const L=`<dialog id="zoomeye-tools-modal" class="modal" autofocus="false">
  <div class="modal-box">
    <form method="dialog">
      <button class="btn btn-sm btn-circle btn-ghost absolute right-2 top-2">✕</button>
    </form>
    <h3 class="text-lg font-bold dialog-title"></h3>
    <p class="py-4 dialog-content text-center"></p>
    <div class="text-center">
      <button class="btn btn-info zoomeye-search hidden">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="1.5em"
          height="1.5em"
          viewBox="0 0 24 24"
        >
          <path
            fill="currentColor"
            d="M9.5 16q-2.725 0-4.612-1.888T3 9.5t1.888-4.612T9.5 3t4.613 1.888T16 9.5q0 1.1-.35 2.075T14.7 13.3l5.6 5.6q.275.275.275.7t-.275.7t-.7.275t-.7-.275l-5.6-5.6q-.75.6-1.725.95T9.5 16m0-2q1.875 0 3.188-1.312T14 9.5t-1.312-3.187T9.5 5T6.313 6.313T5 9.5t1.313 3.188T9.5 14"
          />
        </svg>
        ZoomEye Search
      </button>
    </div>
  </div>
</dialog>`,f=document.createRange(),b=f.createContextualFragment(L);a.appendChild(b);const g=a.querySelector("#zoomeye-tools-modal"),z=a.querySelector(".dialog-title"),s=a.querySelector(".dialog-content"),c=a.querySelector(".zoomeye-search");c.addEventListener("click",()=>{chrome.runtime.sendMessage({type:"createTbsZoomEye",value:s.textContent})});chrome.runtime.onMessage.addListener((t,e,o)=>{var r;const{type:n,value:i}=t;switch(n){case"WebPageModal":const{title:u,loading:h,openModal:p,result:m}=i;z.textContent=u,s.textContent=m,h?(c.classList.add("hidden"),s.classList.add("text-center"),s.innerHTML='<span class="loading loading-spinner loading-lg"></span>'):(c.classList.remove("hidden"),s.classList.remove("text-center"),s.innerHTML=m),p&&!g.open&&(o({selectedText:(r=document.getSelection())==null?void 0:r.toString()}),g.showModal());break}});
