const e={zoomeyeBaseUrl:"https://www.zoomeye.ai",zoomeyeAPIUrl:"https://api.zoomeye.ai",endpoints:{profile:"/profile",apiKey:"/profile#api-key"}};export{e as c};
